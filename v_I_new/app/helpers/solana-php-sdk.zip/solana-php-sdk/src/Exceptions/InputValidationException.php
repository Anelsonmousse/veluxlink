<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

class InputValidationException extends BaseSolanaPhpSdkException
{

}
