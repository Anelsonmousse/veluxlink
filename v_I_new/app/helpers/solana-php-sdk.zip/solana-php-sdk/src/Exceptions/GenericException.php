<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;

class GenericException extends Exception
{

}
