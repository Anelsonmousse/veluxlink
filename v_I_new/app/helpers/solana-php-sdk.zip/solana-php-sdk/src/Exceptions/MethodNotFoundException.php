<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;

class MethodNotFoundException extends Exception
{

}
