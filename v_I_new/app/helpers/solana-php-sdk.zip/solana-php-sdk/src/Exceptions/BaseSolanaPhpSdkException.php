<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;

class BaseSolanaPhpSdkException extends Exception
{

}
