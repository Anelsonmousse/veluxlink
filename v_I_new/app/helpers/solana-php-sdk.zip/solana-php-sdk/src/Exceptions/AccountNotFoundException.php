<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;

class AccountNotFoundException extends Exception
{

}
