<?php


return [

    'TOKEN_PROGRAM_ID' => 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
    'RPC_ENDPOINT' => 'https://api.devnet.solana.com',


];
