# Web3.js Solana SDK Annotations & Usage
---------------

## SPL Token Program

 -- getOrCreateAssociatedTokenAccount (BE)

## Vite Configuration 
    


